import re
import string
import collections #collections is imported for GetHistogram

totalSales = []
frequency = {}
f = open('InputFile.txt', 'r')
for i in f:
    totalSales.append(i.strip()) #Add every item in the file to the list totalSales
f.close()

#This function displays all the options the user has to input
def PrintMenu():
    print("Select an option")
    print("1. Display all items purchased")
    print("2. Find how many times an item was purchased")
    print("3. Display a histogram of all purchases")
    print("4. Quit")

#This function simply prints the contents of totalSales
def ReadFile():
    for i in totalSales:
        print(i.strip())

#This function finds the amount of times an item was purchased
def GetNumPurchases(item):
    count_item = totalSales.count(item)
    print("Number of sales for", item, ":", count_item)

#This function prints an asterik each time an item appears
def GetHistogram():
    frequency = collections.Counter(totalSales) #Fills the previously declared dictionary 'frequency' with each item followed by how many times it appears in the list
    for key, value in frequency.items():
        value = '*' * value
        print(key,value)

#This function is built off a while loop that calls each function based on user input
def GetInput():
    inp = True
    while inp:
        PrintMenu()
        inp = input()
        if inp == '1':
            ReadFile()
        elif inp == '2':
            item = input("Enter an item to find the number of purchases for\n")
            GetNumPurchases(item)
        elif inp == '3':
            GetHistogram()
        elif inp == '4':
            break 
        else:
            print("Please enter a valid command\n")


